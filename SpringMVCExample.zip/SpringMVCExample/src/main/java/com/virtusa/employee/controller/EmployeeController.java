package com.virtusa.employee.controller;

import java.util.ArrayList;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.virtusa.employee.model.Employee;
import com.virtusa.employee.service.EmployeeServiceInterface;
import org.apache.log4j.Logger;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeServiceInterface employeeService;
	
	final static Logger logger = Logger.getLogger(EmployeeController.class);

	public EmployeeController() {
		System.out.println("Employee Controller");
		
	}
	
	@RequestMapping("/welcome1")
	@ResponseBody
	public String  greet() {
		return "Good Morning";
	}
	
	
//	@RequestMapping("/")
//	public String  login() {
//		return "login";
//	}
	
	@RequestMapping("/welcome")
	public String  login(Model model,@ModelAttribute("emp") Employee employee) {
		employee.setUsername("virtusa");
		String[] userType= {"Employee","Admin"};
		model.addAttribute("userType", userType);
		logger.debug("This is debug : ");
		return "login";
	}
	
//	@RequestMapping("/emplyeelogin")
//	public String  validateEmplyee(@RequestParam("username") String username,
//			@RequestParam("password") String password) {
//		
//		String page ="login";
//		
//		
//		if(username.equals("virtusa") && password.equals("123")) {
//			page="employeeHome";
//		}
//		
//		System.out.println("Employee login method is invoked");
//		return page;
//	}
	
	@RequestMapping(path="/emplyeelogin",method=RequestMethod.GET)
	public String  validateEmployeeGet(@ModelAttribute Employee employee) {
		
		String page ="login";
		
		
		if(employee.getUsername().equals("virtusa") && employee.getPassword().equals("123")) {
			page="employeeHome";
		}
		
		System.out.println("Employee login method is invoked");
		return page;
	}
	
	//@RequestMapping(path="/emplyeelogin",method=RequestMethod.POST,params= {"username=virtusa"})
	@RequestMapping(path="/emplyeelogin",method=RequestMethod.POST)
	public String  validateEmployeePost(Model model,@Valid @ModelAttribute("emp") Employee employee,Errors errors) {
		
		String page ="login";
		
		if(errors.hasErrors()) {
			System.out.println(errors.getErrorCount());
			page ="login";
		} else {
		
		if(employee.getUsername().equals("virtusa") && employee.getPassword().equals("123456789")) {
			model.addAttribute("test", "test");
			ArrayList<String> projectList = new ArrayList<String>();
			projectList.add("proj1");
			projectList.add("proj2");
			projectList.add("proj3");
			projectList.add("proj4");
			projectList.add("proj5");
			projectList.add("proj6");
			model.addAttribute("projectList", projectList);
			employeeService.loginService(employee);
			
				System.out.println("Data Added Succesfully");
			
			page="employeeHome";
		}
		}
		
		System.out.println("Employee login method is invoked");
		return page;
	}
}
