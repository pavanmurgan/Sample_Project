package com.virtusa.employee.service;

import com.virtusa.employee.model.Employee;

public interface EmployeeServiceInterface {
	
	public void loginService(Employee employee);

}
