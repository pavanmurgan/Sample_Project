package com.virtusa.employee.DAO;

import com.virtusa.employee.model.Employee;

public interface LoginDAOInterface {
	
	public void loginData(Employee employee);

}
