package com.virtusa.employee.model;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.Entity;  
import javax.persistence.Id;  
import javax.persistence.Table; 

@Entity
@Table(name="emp1000")
public class Employee {
	
	@Id
	@NotEmpty(message="User Name can't be Empty")
	private String username;
	@NotEmpty(message="Password can't be Empty")
	@Length(min=8,max=15,message="minimum 8 and Max 15")
	private String password;
	private String[] userType;
	
	public String[] getUserType() {
		return userType;
	}
	public void setUserType(String[] userType) {
		this.userType = userType;
	}
	public Employee() {
		super();
	}
	public Employee(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
