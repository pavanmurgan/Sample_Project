package com.virtusa.employee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.employee.DAO.LoginDAOInterface;
import com.virtusa.employee.model.Employee;

@Service
public class EmployeeService implements EmployeeServiceInterface {
	
	@Autowired
	private LoginDAOInterface loginDAO;
	
	public EmployeeService() {
		System.out.println("EmployeeService");
	}
	
		
	public void loginService(Employee employee) {
		System.out.println("LoginService");
		loginDAO.loginData(employee);
	}
}
