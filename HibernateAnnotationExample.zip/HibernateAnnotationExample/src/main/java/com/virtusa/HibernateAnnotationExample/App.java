package com.virtusa.HibernateAnnotationExample;



import java.util.List;

import javax.persistence.Query;

/**
 * Hello world!
 *
 */
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


    
public class App {    
public static void main(String[] args) {    
        
    StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
    Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
  
SessionFactory factory = meta.getSessionFactoryBuilder().build();  
Session session = factory.openSession();  
//Transaction t = session.beginTransaction();
//            
//    Employee1 e1=new Employee1();    
//    e1.setId(11045);    
//    e1.setFirstName("arun");    
//    e1.setLastName("thotakuri");    
//        
//    session.save(e1);  
//    t.commit();  
//    System.out.println("successfully saved"); 
    Transaction tx=session.beginTransaction();  
//    Query q=session.createQuery("update Employee1 set id=:n where id=:i");  
//    q.setParameter("n",2);  
//    q.setParameter("i",104);  
//      
//    int status=q.executeUpdate();  
//    System.out.println(status);  
//    tx.commit();
//    factory.close();  
//    session.close();    
    Query query=session.createQuery("from Employee1");//here persistent class name is Emp  
    List<Employee1> list=((org.hibernate.query.Query) query).list(); 
    for(Employee1 model : list) {
        System.out.println(model.getId());
    }  
}    
}   