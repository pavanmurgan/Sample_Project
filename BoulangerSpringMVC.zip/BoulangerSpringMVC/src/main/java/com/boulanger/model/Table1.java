package com.boulanger.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="ReservedTable")
public class Table1 {
	
	@Id
	private String firstName;
	private String lastName;
	private String email;
	private String numberOfPeople;
	private String phone;
	private String date1;
	private String time;
	private String msg;
	
	public Table1() {
		super();
	}

	public Table1(String firstName, String lastName, String email, String numberOfPeople, String phone, String date1,
			String time, String msg) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.numberOfPeople = numberOfPeople;
		this.phone = phone;
		this.date1 = date1;
		this.time = time;
		this.msg = msg;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumberOfPeople() {
		return numberOfPeople;
	}
	public void setNumberOfPeople(String numberOfPeople) {
		this.numberOfPeople = numberOfPeople;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDate1() {
		return date1;
	}
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}
