package com.boulanger.controller;


import java.util.List;
import java.util.Random;


import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.boulanger.model.Items;
import com.boulanger.model.Order;
import com.boulanger.model.Table1;
import com.boulanger.model.Users;
import com.boulanger.service.UserServiceInterface;


@Controller
@Scope("session")
public class UserController {
	
	@Autowired
	private UserServiceInterface userService;
	
	
	
	@RequestMapping("/successPage")
	public String successPage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		
		if(session.getAttribute("email") != null) {
			if(session.getAttribute("email").equals("admin@gmail.com")) {
				return "redirect:errorPage";
			} else {
				return "successPage";
			}
		} else {
			return "redirect:errorPage";
		}
	}
	
	@RequestMapping("/forgotPassword")
	public String forgotPassword() {
		
		return "ForgotPassword";
		
	}
	
	
	@RequestMapping("/forgotPasswordSubmit")
	public String forgotPasswordSubmit(Model model,HttpServletRequest request) {
		
		if(request.getParameter("email") != null) {
		String page = "redirect:signin";
		String email = request.getParameter("email");
		System.out.println(request.getParameter("email"));
		HttpSession session=request.getSession();
		
		if(userService.forgotPasswordService(email)) {
			
			Random rand = new Random();
			int low = 1000;
			int high = 9999;
			int otp = rand.nextInt(high-low) + low;
			
			System.out.println("OPT generated");
			
			model.addAttribute("otp", otp);
			model.addAttribute("email1", email);
			System.out.println(otp);
			
			page = "ResetPassword";
			
		} else {
			
			session.setAttribute("mes", "User Not Registred");
		}
		
		return page;
		} else {
			return "redirect:errorPage";
		}
	}
	
	@RequestMapping("resetPasswordSubmit")
	public String resetPasswordSubmit(HttpServletRequest request) {
		String page = "ResetPassword";
		HttpSession session=request.getSession();
		
		int userOtp = Integer.parseInt(request.getParameter("OTP").toString());
		String email = request.getParameter("email1").toString();
		int otp = Integer.parseInt(request.getParameter("otp1").toString());
		
		if(userOtp == otp) {
		
			Users u = new Users();
			u.setUserPassword(request.getParameter("ResetPassword"));
			u.setUserEmail(email);
			userService.passwordChangeService(u);
			session.setAttribute("mes", "Password Changed Successfully");
			page="redirect:signin";
		} else {
			session.setAttribute("mes1", "Incorrect OTP");
		}
		
		return page;
	}
	
	
	@RequestMapping("/")
	public String homePage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.setAttribute("email", null);
		session.setAttribute("mes", "");
		session.setAttribute("mes1", "");
		
		return "index";
	}
	
	@RequestMapping("/index")
	public String indexPage(HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.setAttribute("mes", "");
		return "index";
	}

	@RequestMapping("/reservation")
	public String reservation() {
		return "Reservation";
	}
	
	
	@RequestMapping("/errorPage")
	public String errorPage() {
		return "errorPage";
	}
	
	@RequestMapping("/profile")
	public String profilePage(Model model,HttpServletRequest request) {
		
		HttpSession session=request.getSession();
		String email = session.getAttribute("email").toString();
		
		Users u = new Users();
		u.setUserEmail(email);
		Users user = userService.userDataService(u);
		List<Order> orders = userService.orderDataService(email);
			if(user.getUserAddress().equals("b")) {
				user.setUserAddress("");
			}
			if(user.getUserName().equals("a")) {
				user.setUserName("");
			}
		model.addAttribute("user",user);
		model.addAttribute("orders", orders);
		session.setAttribute("address", user.getUserAddress());
		return "profile";
	}
	
	
	@RequestMapping("/signup")
	public String loginPage(@ModelAttribute("reg") Users user,HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.setAttribute("mes", "");
		return "Registration";
	}
	
	@RequestMapping("/signupSubmit")
	public String signup(@Valid @ModelAttribute("reg") Users user,Errors errors,HttpServletRequest request) {
		HttpSession session=request.getSession();
		String page ="redirect:signup";
		
		if(errors.hasErrors()) {
			System.out.println(errors.getErrorCount());
		} else {
			
			if(user.getUserEmail().equals("admin@gmail.com")) {			
				
			} else {
				user.setUserAddress("b");
				user.setUserName("a");
				try {
				userService.signupService(user);
				session.setAttribute("mes", "Registred Successfully");
				} catch(Exception e) {
					session.setAttribute("mes", "User already Registred");
				}
				page="redirect:signin";
			}
		}
		
		return page;
		
	}
	
	@RequestMapping("/cart")
	public String cartPage(Model model,HttpServletRequest request) {
		
		System.out.println(request.getParameter("val"));
		
		HttpSession session=request.getSession();
		session.setAttribute("val", request.getParameter("val").toString());
		
		Items i = userService.itemDataService(request.getParameter("val").toString());
		model.addAttribute("i",i);
		
		return "cart";
	}
	
	@RequestMapping("/signin")
	public String signinPage(Model model,@ModelAttribute("sig") Users user,HttpServletRequest request) {
		HttpSession session=request.getSession();
		model.addAttribute("mes", session.getAttribute("mes").toString());
		return "login";
	}
	
	
	
	@RequestMapping("/loginSubmit")
	public String loginSubmit(@Valid @ModelAttribute("sig") Users user,Errors errors,HttpServletRequest request) {
		
		String page ="redirect:signin";
		System.out.println(request.getParameter("User"));
		String option = request.getParameter("User");
		HttpSession session=request.getSession();
		
		
		
		
		if(errors.hasErrors()) {
			System.out.println(errors.getErrorCount());
		} else {
			
			if(option.equals("User")) {
			
				if(userService.siginService(user)) {
					
					session.setAttribute("email", user.getUserEmail());
					page="redirect:profile";
				} else {
					session.setAttribute("mes", "Invalid Credentials");
					page="redirect:signin";
				}
				
			} else {
				
				if(userService.adminsigninService(user)) {
					session.setAttribute("adminemail", user.getUserEmail());
					page="redirect:admin";
				} else {
					session.setAttribute("mes", "Invalid Credentials");
					page="redirect:signin";
				}
				
				
			}
			
		}
		
		
		return page;
	}
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session=request.getSession();  
        session.invalidate();
		return "redirect:index";
	}
	
	
	@RequestMapping("/checkout")
	public String checkoutPage(Model model,HttpServletRequest request) {
		
		HttpSession session=request.getSession();
		System.out.println(request.getParameter("quantity"));
        session.setAttribute("quantity",request.getParameter("quantity").toString());
        
        Items i = userService.itemDataService(session.getAttribute("val").toString());
        
        Double i123 = i.getItemCost();
		int q = Integer.parseInt(session.getAttribute("quantity").toString());
		
		Double sum = i123 * q;
		
		session.setAttribute("sum",sum);
		model.addAttribute("i1", i);
        
        return "checkout";
	}
	
	@RequestMapping("/menu")
	public String menuPage(Model model) {
		
		List<Items> l = userService.itemsDataService();
		
		model.addAttribute("items",l);
		
		return "menu";
	}
	
	@RequestMapping("/contact")
	public String contactPage() {
		return "contact";
	}
	
	
	@RequestMapping("/orderSubmit")
	public String orderSubmit(HttpServletRequest request) {
		
		
		HttpSession session=request.getSession();
		
		Random rand = new Random();
		
		Items i = userService.itemDataService(session.getAttribute("val").toString());
		
		Order o = new Order();
		o.setEmail(session.getAttribute("email").toString());
		o.setItemName(i.getItemName());
		o.setAddress(session.getAttribute("address").toString());
		o.setQuantity(session.getAttribute("quantity").toString());
		o.setAmount(session.getAttribute("sum").toString());
		o.setOrderNo(""+rand.nextInt(13487)+"");
		
		userService.orderDataSaveService(o);
		
		return "redirect:successPage";
		
	}
	
	@RequestMapping("/reservationSubmit")
	public String reservationSubmit(HttpServletRequest request) {
		Table1 t = new Table1();
		t.setFirstName(request.getParameter("mfname"));
		t.setLastName(request.getParameter("mlname"));
		t.setEmail(request.getParameter("memail"));
		t.setNumberOfPeople(request.getParameter("mpeople"));
		t.setPhone(request.getParameter("mphone"));
		t.setDate1(request.getParameter("mdate"));
		t.setTime(request.getParameter("mtime"));
		t.setMsg(request.getParameter("mmessage"));
		userService.reservationDataSaveService(t);
		return "redirect:index";
	}
	
	
}
