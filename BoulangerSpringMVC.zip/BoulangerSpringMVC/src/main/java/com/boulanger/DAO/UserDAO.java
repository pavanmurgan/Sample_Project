package com.boulanger.DAO;

import java.util.List;



import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.boulanger.model.Admin;
import com.boulanger.model.Items;
import com.boulanger.model.Order;
import com.boulanger.model.Table1;
import com.boulanger.model.Users;


@Repository
public class UserDAO implements UserDAOInterface{

	
	@Autowired
    private SessionFactory sessionFactory;
	
	@Override
	@Transactional
	public void signupData(Users user) throws Exception {
		
		sessionFactory.getCurrentSession().save(user);
	}

	@Override
	@Transactional
	public Users loginData(String email) {
		// TODO Auto-generated method stub
		
		List<Users> result = sessionFactory.getCurrentSession().createQuery("from Users where userEmail=:email").setParameter("email",email).list();
		 
	    Users u1 = null;
	    for(Users user : result) {
	    	u1 = new Users(user.getUserName(),user.getUserEmail(),user.getUserPassword(),user.getUserMobileNumber(),user.getUserAddress());
	       
	    }  
        
        return u1;
		
	}

	@Override
	@Transactional
	public void addItemData(Items item) {
		
		sessionFactory.getCurrentSession().save(item);
		// TODO Auto-generated method stub
		
	}

	@Override
	@Transactional
	public List<Items> itemsData() {
		
		List<Items> result = sessionFactory.getCurrentSession().createQuery("from Items").list();
		
		// TODO Auto-generated method stub
		return result;
	}

	@Override
	@Transactional
	public Items itemData(String itemId) {
		
		Items item = null;
		List<Items> result = sessionFactory.getCurrentSession().createQuery("from Items where itemId=:i").setParameter("i", itemId).list();
		
		for(Items r : result) {
			item = r;
			System.out.println(r.getItemName());
		}
		
		// TODO Auto-generated method stub
		return item;
	}

	@Override
	@Transactional
	public void orderDataSave(Order order) {
		
		sessionFactory.getCurrentSession().save(order);
		// TODO Auto-generated method stub
		
	}

	@Override
	@Transactional
	public List<Order> orderData(String email) {
		
		//List<Order> result = sessionFactory.getCurrentSession().createQuery("from Order where email=:email").setParameter("email",email).list();
		Criteria c = sessionFactory.getCurrentSession().createCriteria(Order.class);
		SimpleExpression ex = Restrictions.eq("email", email);
		c.add(ex);
		
		List<Order> result = c.list();
		
		// TODO Auto-generated method stub
		return result;
	}

	@Override
	@Transactional
	public void reservationDataSave(Table1 table) {
		
		sessionFactory.getCurrentSession().save(table);
		// TODO Auto-generated method stub
		
	}

	@Override
	@Transactional
	public List<Table1> reservationData() {
		
		List<Table1> result = sessionFactory.getCurrentSession().createQuery("from Table1").list();
		
		// TODO Auto-generated method stub
		return result;
	}

	@Override
	@Transactional
	public List<Order> orderData1() {
		
		List<Order> result = sessionFactory.getCurrentSession().createCriteria(Order.class).list();
		// TODO Auto-generated method stub
		return result;
	}

	@Override
	@Transactional
	public Admin adminData() {
		Admin a = new Admin();
		// TODO Auto-generated method stub
		List<Admin> result = sessionFactory.getCurrentSession().createCriteria(Admin.class).list();
		for(Admin r : result) {
			a = r;
		}
		return a;
	}

	@Override
	@Transactional
	public void passwordChange(Users user) {
		
		Query q = sessionFactory.getCurrentSession().createQuery("update Users set userPassword=:a where userEmail=:e");
		q.setParameter("a",user.getUserPassword());
		q.setParameter("e", user.getUserEmail());
		q.executeUpdate();
		// TODO Auto-generated method stub
		
	}

}
