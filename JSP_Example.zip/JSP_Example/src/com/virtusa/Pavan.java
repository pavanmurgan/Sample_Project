package com.virtusa;

public class Pavan {
	
	int i;
	public int sampleFunc() {
		i= 10;
		return i;		
	}

}
