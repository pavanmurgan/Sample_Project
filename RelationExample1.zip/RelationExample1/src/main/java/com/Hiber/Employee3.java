package com.Hiber;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity  
@Table(name= "emp14")
public class Employee3 {
	
	@Id
	private int personId;
	private String personName;
	
	@OneToOne
	private Employee4 emp;
	
	
	public Employee4 getEmp() {
		return emp;
	}
	public void setEmp(Employee4 emp) {
		this.emp = emp;
	}
	public int getPersonId() {
		return personId;
	}
	public void setPersonId(int personId) {
		this.personId = personId;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	

}
