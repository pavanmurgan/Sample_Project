package com.Hiber;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration config = new Configuration();
    	config.configure("hibernate.cfg.xml");
    	
    	SessionFactory factory = config.buildSessionFactory(); 
    	Session session = factory.openSession();  
    	Transaction t = session.beginTransaction();
    	            
    	    Employee3 e1=new Employee3();    
    	    e1.setPersonId(23);    
    	    e1.setPersonName("Ramya");
    	    Employee4 a = new Employee4();
    	    a.setVechileId(24);
    	    a.setVechileName("Hyderabad");
    	    e1.setEmp(a);
    	    session.save(a);
    	    session.save(e1);
    	    t.commit();  
    	    session.close();
    	    System.out.println("successfully saved"); 
    }
}
