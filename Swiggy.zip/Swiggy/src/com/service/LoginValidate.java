package com.service;

import java.sql.SQLException;

import com.dao.DAO;
import com.main.User;

public class LoginValidate {
	
	public boolean validateUser(User u) throws SQLException{
		DAO dao = new DAO();
		User u1 = dao.validateLogin(u);
		if(u!=null&&u1!=null)
		{
			if((u.getUserName().equals(u1.getUserName()))&&(u.getUserPassword().equals(u1.getUserPassword())))
			{
				return true;
			}
		
		}
		
		return false;
		

}

}
