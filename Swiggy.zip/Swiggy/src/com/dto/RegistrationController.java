package com.dto;

import java.sql.SQLException;
import java.util.Scanner;

import com.dao.DAO;
import com.main.User;

public class RegistrationController {
	
	String userName;
	String password;
	String mobileNumber;
	
	public void register() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Username");
		userName = sc.nextLine();
		
		System.out.println("Enter Password");
		password = sc.nextLine();
		
		System.out.println("Enter Moble Number");
		mobileNumber = sc.nextLine();
		
		User u = new User(userName,password,mobileNumber);
		
		DAO dao = new DAO();
		
		try {
			
			int result = dao.insertUserData(u);
			if(result != 0){
				System.out.println("Data inserted in the database");
			}
			else{
				System.out.println("Error");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
