package com.dto;

import java.util.Scanner;

public class HomePageController {
	
	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		
		int option;
		boolean re = true; 
		
		System.out.println("Welcome to Swiggy");
		
		while(re) {
			
			System.out.println("Enter your choice");
			System.out.println("1.Login\n2.Register");
			
			option = sc.nextInt();
			
			switch(option) {
			
			case 1:
				LoginController log = new LoginController();
				log.login();
				re = false;
				System.out.println("Login Succesful");
				break;
			
			case 2:
				RegistrationController reg = new RegistrationController();
				reg.register();
				System.out.println("Register Succesful");
				break;
			
			default:
				System.out.println("Enter Correct choice");
			
			}
		}
		
	}

}
