package com.dto;

import java.sql.SQLException;
import java.util.Scanner;

import com.main.User;
import com.service.LoginValidate;

public class LoginController {
	
	String userName;
	String password;
	
	public void login() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Username");
		userName = sc.nextLine();
		
		System.out.println("Enter Password");
		password = sc.nextLine();
		
		User u = new User(userName,password);
		
		LoginValidate service = new LoginValidate();
		
		try {
			if(service.validateUser(u)){
				System.out.println("Login Successfull");
			}
			else{
				System.out.println("Incorrect");
							}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
}
