package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jdbc.DatabaseConnection;
import com.main.User;

public class DAO {
	DatabaseConnection d = new DatabaseConnection();
	Connection conn = d.getDBConnection();
	
	public int insertUserData(User u) throws ClassNotFoundException, SQLException{
		
		String sql = "insert into User1 values(?,?,?)";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1, u.getUserName());
		pst.setString(2, u.getUserPassword());
		pst.setString(3, u.getMobileNumber());
		return pst.executeUpdate();
	}
	
	public User validateLogin(User u) throws SQLException{
		
		String sql = "select * from User1 where userName=? and password=?";
		PreparedStatement pst = conn.prepareStatement(sql);
		pst.setString(1,u.getUserName());
		pst.setString(2,u.getUserPassword());
		ResultSet rs = pst.executeQuery();
		User u1 = null;
		if(rs.next())
		{
			u1 = new User(rs.getString(1),rs.getString(2));
		}
		return u1;
		
	}

}
