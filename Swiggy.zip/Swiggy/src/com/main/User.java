package com.main;

public class User {
	
	private String userName;
	private String userPassword;
	private String mobileNumber;
	
	public User(String userName, String userPassword, String mobileNumber) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
		this.mobileNumber = mobileNumber;
	}
	
	public User(String userName, String userPassword) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
	}

	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getUserPassword() {
		return userPassword;
	}
	
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

}
