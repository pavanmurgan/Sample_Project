package com.Hib;

import javax.persistence.Entity;  
import javax.persistence.Id;  
import javax.persistence.Table;  
  
@Entity  
@Table(name= "emp12")   
public class Employee2 {    
  
@Id   
private int empId; 
private int age;
private String userName;
private Address a = new Address();

public Address getA() {
	return a;
}
public void setA(Address a) {
	this.a = a;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}    
    
   
}   
