package com.Hib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//    	 StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
//    	    Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
//    	  
    	Configuration config = new Configuration();
    	config.configure("hibernate.cfg.xml");
    	
    	SessionFactory factory = config.buildSessionFactory(); 
    	Session session = factory.openSession();  
    	Transaction t = session.beginTransaction();
    	            
    	    Employee2 e1=new Employee2();    
    	    e1.setEmpId(10);    
    	    e1.setUserName("Vicky");    
    	    e1.setAge(25);    
    	    Address a = new Address();
    	    a.setStreet("Gowlidoddy");
    	    a.setCity("Hyderabad");
    	    a.setPincode(123456);
    	    e1.setA(a);
    	    session.save(e1);
    	    t.commit();  
    	    session.close();
    	    System.out.println("successfully saved"); 
    }
}
