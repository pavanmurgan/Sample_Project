package com.main;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Items implements java.io.Serializable {
	
	@Id
	private String itemName;
	private String itemId;
	private String itemDescription;
	private Double itemCost;
	private byte[] itemImage;
	
	
	
	public Items() {
		super();
	}
	public Items(String itemName, String itemId, String itemDescription, Double itemCost, byte[] itemImage) {
		super();
		this.itemName = itemName;
		this.itemId = itemId;
		this.itemDescription = itemDescription;
		this.itemCost = itemCost;
		this.itemImage = itemImage;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public Double getItemCost() {
		return itemCost;
	}
	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}
	public byte[] getItemImage() {
		return itemImage;
	}
	public void setItemImage(byte[] itemImage) {
		this.itemImage = itemImage;
	}
	

}
