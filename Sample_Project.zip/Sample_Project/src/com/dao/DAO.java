package com.dao;

import java.io.FileOutputStream;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.HibernateConnection.Hibernate_Connection;
import com.main.Items;
import com.main.Users;



public class DAO {
	
	Hibernate_Connection h = new Hibernate_Connection();
	Session session = h.getConnection();

	public Items addItem(Items i) {
	   
	    Transaction t = session.beginTransaction();
	    
	    session.save(i); 
	    String s = "Pavan123";
	    List<Items> result = session.createQuery("from Items where itemId=:itemid").setParameter("itemid",s).list();
		 
	    Items i1 = null;
	    for(Items item : result) {
	    	i1 = new Items(item.getItemName(),item.getItemId(),item.getItemDescription(),item.getItemCost(),item.getItemImage());
	    }  
	    
	    
	   
        byte[] bAvatar = i1.getItemImage();
        
//        try{
//            FileOutputStream fos = new FileOutputStream("C:\\Users\\pavanm\\Desktop\\pavan\\Sample_Project.zip\\Sample_Project\\WebContent"); 
//            fos.write(bAvatar);
//            fos.close();
//        }catch(Exception e){
//            e.printStackTrace();
//        }
        
        //byte[] thumb = userService.getCurrentUserAvatar();

        
        //session.getTransaction().commit();
	    
	    t.commit();  
	    
	
	    session.close();
	    
		System.out.println("Saved");
		return i1;
	
   }
	
	public void addUser(Users u) {
		
		Transaction tx=session.beginTransaction();
		
			
		session.save(u);
		tx.commit();
		
		session.close();
	
		System.out.println("Saved");
		
	}
	
	public Users loginData(String email) {
		
		
		System.out.println("Came");
		Transaction tx=session.beginTransaction();
		
			
		
		List<Users> result = session.createQuery("from Users where email=:email").setParameter("email",email).list();
		 
	    Users u1 = null;
	    for(Users user : result) {
	    	u1 = new Users(user.getEmail(),user.getPassword());
	        System.out.println(user.getEmail());
	        System.out.println(user.getPassword());
	    }  
        
	    tx.commit();
        session.close();
        return u1;
	    
	}
}
