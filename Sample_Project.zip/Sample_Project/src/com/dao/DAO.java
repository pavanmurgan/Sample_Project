package com.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.HibernateConnection.HibernateConnection;
import com.main.Admin;
import com.main.Items;
import com.main.Order;
import com.main.Table1;
import com.main.Users;



public class DAO {
	
	HibernateConnection h = new HibernateConnection();
	Session session = h.getConnection();

	
	public void addTable(Table1 t) {
		
		Transaction tx=session.beginTransaction();
		
		
		session.save(t);
		tx.commit();
	
	
		System.out.println("Saved");
		
	}
	
	
	public void addItem(Items i) {
	   
	    Transaction t = session.beginTransaction();
	    
	    session.save(i);
	    
	    t.commit();
	    	
	 
	    
		System.out.println("Saved");
		
	
   }
	
	
	public void addOrders(Order o1) {
		
		Transaction tx=session.beginTransaction();
		
		
		session.save(o1);
		tx.commit();
	
	
		System.out.println("Saved");
		
	}
	
	public List<Items> getItemsData() {
		
		Transaction tx=session.beginTransaction();
		
		List<Items> result = session.createQuery("from Items").list();
		tx.commit();
	    
		return result;
	}
	
	public Items getItemData(String id) {
		Items item = null;
		
		Transaction tx=session.beginTransaction();
		
		List<Items> result = session.createQuery("from Items where itemId=:i").setParameter("i", id).list();
		
		for(Items r : result) {
			item = r;
		}
		
		tx.commit();
		
		
		return item;
	}
	
	
	public void addUser(Users u) {
		
		Transaction tx=session.beginTransaction();
		
			
		session.save(u);
		tx.commit();
	
		System.out.println("Saved");
		
	}
	
	public Users loginData(String email) {
		
		
		System.out.println("Came");
		Transaction tx=session.beginTransaction();
		
			
		
		List<Users> result = session.createQuery("from Users where email=:email").setParameter("email",email).list();
		 
	    Users u1 = null;
	    for(Users user : result) {
	    	u1 = new Users(user.getUserName(),user.getEmail(),user.getPassword(),user.getMobileNumber(),user.getAddress());
	        System.out.println(user.getEmail());
	        System.out.println(user.getPassword());
	    }  
        
	    tx.commit();
       
        return u1;
	    
	}
	
	
	public Admin adminloginData(String email) {
		Transaction tx=session.beginTransaction();
		
		List<Admin> result = session.createQuery("from Admin where email=:e").setParameter("e",email).list();
		 
	    Admin a1 = null;
	    for(Admin admin : result) {
	    	a1 = new Admin(admin.getUserName(),admin.getEmail(),admin.getPassword(),admin.getMobileNumber(),admin.getAddress());
	        System.out.println(admin.getEmail());
	        System.out.println(admin.getPassword());
	    }  
        
	    tx.commit();
      
        return a1;
	}
	
	
	
	
	
	
	public boolean updateUserData(String email,String value,String option) {
		
		boolean status = false;
		try {
	    Transaction tx=session.beginTransaction();  
	    Query q;
	    
	    
	    switch(option) {
	    case "name":
	    	q=session.createQuery("update Users set userName=:a where email=:e"); 
	    	break;
	    case "email":
	    	q=session.createQuery("update Users set email=:a where email=:e"); 
	    	break;
	    case "address":
	    	q=session.createQuery("update Users set address=:a where email=:e");
	    	break;
	    case "mobileNumber":
	    	
	    	q=session.createQuery("update Users set mobileNumber=:a where email=:e");
	    	break;
	    default:
	    	 q=session.createQuery("update Users set simply=:a where email=:e"); 
	    	 break;
	    }
	    
	    long l = 0;
	    if(option.equals("mobileNumber")) {
	    	l = Long.parseLong(value);
	    	q.setParameter("a",l);
	    }
	    else {
	    q.setParameter("a",value);
	    }
	    q.setParameter("e",email);  
	    
	    
	    int s=q.executeUpdate();
	    if(s>0) {
	    	status = true;
	    }
	    System.out.println(status);  
	    tx.commit();
		} catch(Exception e) {
			return status;
		}
		return status;
		
	}
	
	public boolean updatePassword(Users u) {
		
		
		 Transaction tx=session.beginTransaction();  
		    Query q = session.createQuery("update Users set password=:a where email=:e");
		    		q.setParameter("a",u.getPassword());
		    		q.setParameter("e", u.getEmail());
		    		if(q.executeUpdate() > 0) {
		    			return true;
		    		}
		  return false;
	}
	
	public List<Table1> tableData() {
		
		Transaction tx=session.beginTransaction();
		
		List<Table1> result = session.createQuery("from Table1").list();
		 
	    tx.commit();
        session.close();
        return result;
		
	}
	
	public List<Order> orderData(String email) {
		
		Transaction tx=session.beginTransaction();
		
		List<Order> result = session.createQuery("from Order where email=:email").setParameter("email",email).list();
		 
	    tx.commit();
        
        return result;
		
	}
	
public List<Order> orderData1() {
		
		Transaction tx=session.beginTransaction();
		
		List<Order> result = session.createQuery("from Order").list();
		 
	    tx.commit();
        
        return result;
		
	}
	
	
}
