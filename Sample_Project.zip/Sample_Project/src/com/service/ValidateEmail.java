package com.service;

import com.dao.DAO;
import com.main.Users;

public class ValidateEmail {
	
	
	public boolean emailValidation(String email) {
		
		DAO d = new DAO();
		Users u = d.loginData(email);
		if(u != null) {
			return true;
		} else {
		return false;
		}
	}
	

}
