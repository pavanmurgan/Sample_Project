package com.service;

import java.sql.SQLException;

import com.dao.DAO;
import com.main.Users;

public class LoginValidation {
	
	public boolean validateUser(Users u) {
		
		DAO dao = new DAO();
		
		
		Users u1 = dao.loginData(u.getEmail());
		
		if(u!=null&&u1!=null)
		{
			System.out.println(u1.getPassword());
			if((u.getEmail().equals(u1.getEmail()))&&(u.getPassword().equals(u1.getPassword())))
			{
				return true;
			}
		
		}
		
		return false;
		}

}
