package com.service;

import java.sql.SQLException;

import com.dao.DAO;
import com.main.Admin;
import com.main.Users;

public class LoginValidation {
	
	public boolean validateUser(Users u) {
		
		DAO dao = new DAO();
		
		
		Users u1 = dao.loginData(u.getEmail());
		
		if(u!=null&&u1!=null)
		{
			System.out.println(u1.getPassword());
			if((u.getEmail().equals(u1.getEmail()))&&(u.getPassword().equals(u1.getPassword())))
			{
				return true;
			}
		
		}
		
		return false;
		}
	
	public boolean validateAdmin(Admin a) {
		
		DAO dao = new DAO();
		
		Admin a1 = dao.adminloginData(a.getEmail());
		
		if(a!=null&&a1!=null)
		{
			System.out.println(a1.getPassword());
			if((a.getEmail().equals(a1.getEmail()))&&(a.getPassword().equals(a1.getPassword())))
			{
				return true;
			}
		
		}
		
		return false;
		
	}
	
	
	

}
