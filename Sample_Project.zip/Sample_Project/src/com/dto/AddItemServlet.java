package com.dto;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.main.Items;

/**
 * Servlet implementation class Item_Add
 */
@WebServlet("/AddItemServlet")
public class AddItemServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
		 
		File file = new File("file://"+request.getParameter("itemImage"));
		
        byte[] bFile = new byte[(int) file.length()];
        
        try {
   	     FileInputStream fileInputStream = new FileInputStream(file);
   	     
   	     fileInputStream.read(bFile);
   	     fileInputStream.close();
         
        } catch (Exception e) {
        	 e.printStackTrace();
        }
        
        Items i = new Items();
        
        i.setItemName(request.getParameter("itemName"));
		i.setItemId(request.getParameter("itemId"));
		i.setItemDescription(request.getParameter("itemDescription"));
		i.setItemCost(Double.parseDouble(request.getParameter("itemCost")));
		i.setItemImage(bFile);
		
		DAO d = new DAO();
		Items i3 = d.addItem(i);
		
		byte[] thumb = i3.getItemImage();

        String name = "userAvatar";
        response.setContentType("image/jpeg");
        response.setContentLength(thumb.length);

        response.setHeader("Content-Disposition", "inline; filename=\"" + name
                + "\"");

        BufferedInputStream input = null;
        BufferedOutputStream output = null;

        try {
            input = new BufferedInputStream(new ByteArrayInputStream(thumb));
            output = new BufferedOutputStream(response.getOutputStream());
            byte[] buffer = new byte[8192];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }
        } catch (IOException e) {
            System.out.println("There are errors in reading/writing image stream "
                    + e.getMessage());
        } finally {
            if (output != null)
                try {
                    output.close();
                } catch (IOException ignore) {
                }
            if (input != null)
                try {
                    input.close();
                } catch (IOException ignore) {
                }
        }
		
		
		
		doGet(request, response);
		
	}

}
