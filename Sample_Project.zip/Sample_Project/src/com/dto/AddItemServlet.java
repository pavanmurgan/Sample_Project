package com.dto;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.main.Items;

/**
 * Servlet implementation class Item_Add
 */
@WebServlet("/AddItemServlet")
public class AddItemServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		try {
		Random rand = new Random();
		
		int z = rand.nextInt(13487);
		BufferedImage image = null;
        try {
          
            File file1 = new File(request.getParameter("itemImage"));
            System.out.println(request.getParameter("itemImage"));
            image = ImageIO.read(file1);
            
            ImageIO.write(image, "jpg",new File("C:\\Users\\pavanm\\Desktop\\pavan\\Sample_Project\\WebContent\\image1\\"+z+".jpg"));
            
            
        } catch (IOException e) {
        	e.printStackTrace();
        }
        System.out.println("Done");
  
        Items i = new Items();
        
        i.setItemName(request.getParameter("itemName"));
		i.setItemId(request.getParameter("itemId"));
		i.setItemDescription(request.getParameter("itemDescription"));
		i.setItemCost(Double.parseDouble(request.getParameter("itemCost")));
		i.setItemImageUrl(z+".jpg");
		
		DAO d = new DAO();
		d.addItem(i);
		
		out.println("<html><body>");
		out.println("<p>Item added Successfully</p><br>");
		out.println("<a href='index.jsp'>Home</a><br>");
		out.println("<a href='admin.jsp'>Back</a><br>");
		out.println("</body></html>");
		} catch(Exception e) {
			out.println("<html><body>");
			out.println("<p>Item Id already Available</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("<a href='admin.jsp'>Back</a><br>");
			out.println("</body></html>");
		}
		doGet(request, response);
		
	}

}
