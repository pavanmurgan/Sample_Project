package com.dto;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DAO;
import com.main.Users;

/**
 * Servlet implementation class ResetPasswordServlet
 */
@WebServlet("/ResetPasswordServlet")
public class ResetPasswordServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session3 = request.getSession();
		PrintWriter out = response.getWriter();
		int userOtp = Integer.parseInt(request.getParameter("OTP").toString());
		String email = session3.getAttribute("email").toString();
		
		
		int otp = Integer.parseInt(session3.getAttribute("otp").toString());
		System.out.println(otp);
		
		if(userOtp == otp) {
			
			Users u = new Users();
			u.setPassword(request.getParameter("ResetPassword"));
			u.setEmail(email);
			DAO d = new DAO();
			if(d.updatePassword(u)) {
				session3.invalidate();
				out.println("<html><body>");
				out.println("<p>Updated Successfully</p><br>");
				out.println("<a href='index.jsp'>Home</a><br>");
				out.println("</body></html>");
			}
			
		} else {
			session3.invalidate();
			out.println("<html><body>");
			out.println("<p>Wrong OTP</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("</body></html>");
		}
		
		doGet(request, response);
	}

}
