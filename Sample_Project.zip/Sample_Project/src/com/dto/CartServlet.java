package com.dto;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		System.out.println(request.getParameter("quantity"));
		HttpSession session=request.getSession();  
	       
        session.setAttribute("quantity",quantity);
		
        RequestDispatcher rd=request.getRequestDispatcher("checkout.jsp");
		rd.forward(request,response);
		
		doGet(request, response);
	}

}
