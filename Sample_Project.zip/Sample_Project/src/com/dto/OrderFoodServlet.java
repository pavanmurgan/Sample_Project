package com.dto;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DAO;
import com.main.Order;

/**
 * Servlet implementation class OrderFoodServlet
 */
@WebServlet("/OrderFoodServlet")
public class OrderFoodServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Random rand = new Random();
		PrintWriter out = new PrintWriter(System.out);
		HttpSession session5=request.getSession();
		Order o = new Order();
		o.setEmail(session5.getAttribute("email").toString());
		o.setItemName(session5.getAttribute("itemName").toString());
		o.setAddress(session5.getAttribute("address").toString());
		o.setQuantity(session5.getAttribute("quantity").toString());
		o.setAmount(session5.getAttribute("sum").toString());
		o.setOrderNo(""+rand.nextInt(13487)+"");
		
		DAO d = new DAO();
		d.addOrders(o);
		
		out.println ("<html><body><script>alert('Hello World!');</script></body></html>");
        RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request,response);
		
		doGet(request, response);
	}

}
