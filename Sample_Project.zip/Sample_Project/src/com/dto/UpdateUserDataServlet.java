package com.dto;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;


@WebServlet("/UpdateUserDataServlet")
public class UpdateUserDataServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String option = request.getParameter("value");
		String value ="";
	
		
		switch(option) {
		case "name":
			value = request.getParameter("userName");
			break;
		case "address":
			value = request.getParameter("userAddress");
			break;
		case "email":
			value = request.getParameter("userEmail");
			break;
		case "mobileNumber":
			value = request.getParameter("userMobileNumber");
			break;
		default:
			value = "a";
			break;
		}
		
		
		DAO d =  new DAO();
		if(d.updateUserData(request.getParameter("email"),value,option)) {
			System.out.println("Updated");
			RequestDispatcher rd=request.getRequestDispatcher("profile.jsp");
			rd.forward(request,response);
		}
		else {
			out.println("<html><body>");
			out.println("<p>Invalid Data</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("<a href='Registeration.jsp'>Back</a><br>");
			out.println("</body></html>");
		}
		
		doGet(request, response);
	}

}
