package com.dto;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.PersistenceException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.main.Users;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		Users user = new Users();
		try {
			if(request.getParameter("email").toString().equals("admin@gmail.com")) {
				out.println("<html><body>");
				out.println("<p>This Email is not allowded for registration</p><br>");
				out.println("<a href='index.jsp'>Home</a><br>");
				out.println("<a href='Registration.jsp'>Back</a><br>");
				out.println("</body></html>");
			} else {
		user.setEmail(request.getParameter("email"));
		user.setAddress(request.getParameter("address"));
		user.setUserName(request.getParameter("userName"));
		user.setPassword(request.getParameter("password"));
		user.setMobileNumber(Long.parseLong(request.getParameter("mobileNumber")));
		
		DAO d = new DAO();
		d.addUser(user);
		
		RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
		rd.forward(request,response);
			}
		} catch(PersistenceException s) {
			out.println("<html><body>");
			out.println("<p>User Already Registred</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("<a href='Registration.jsp'>Back</a><br>");
			out.println("</body></html>");
			
		}
		catch(Exception e) {
			out.println("<html><body>");
			out.println("<p>Invalid Data</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("<a href='Registration.jsp'>Back</a><br>");
			out.println("</body></html>");
		}
		doGet(request, response);
	}

}
