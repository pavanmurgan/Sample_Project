package com.dto;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.service.ValidateEmail;

/**
 * Servlet implementation class ForgotPasswordServlet
 */
@WebServlet("/ForgotPasswordServlet")
public class ForgotPasswordServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		
		String email = request.getParameter("email");
		
		ValidateEmail v = new ValidateEmail();
		if(v.emailValidation(email)) {
			Random rand = new Random();
			int low = 1000;
			int high = 9999;
			int otp = rand.nextInt(high-low) + low;
			
			System.out.println("OPT generated");
			HttpSession session = request.getSession();
			session.setAttribute("otp", otp);
			session.setAttribute("email", email);
			System.out.println(otp);
			RequestDispatcher rd=request.getRequestDispatcher("ResetPassword.jsp");
			rd.forward(request,response);
		} else {
			out.println("<html><body>");
			out.println("<p>Not a Registered User</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("</body></html>");
		}
		
		doGet(request, response);
	}

}
