package com.dto;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.main.Admin;
import com.main.Users;
import com.service.LoginValidation;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String option = request.getParameter("User");
		LoginValidation l = new LoginValidation();
		
		try {
		if(option.equals("User")) {
		
		Users u = new Users(email,password);
		
		if(l.validateUser(u)) {
			System.out.println("Loged in");
			HttpSession session=request.getSession();  
		       
	        session.setAttribute("email",email);
				RequestDispatcher rd=request.getRequestDispatcher("profile.jsp");
				rd.forward(request,response);
		} else {
			
			
			
			out.println("<html><body>");
			out.println("<p>Invalid credentials</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("<a href='Registration.jsp'>Back</a><br>");
			out.println("</body></html>");
			
			
		}
		
		} else {
			
			Admin a = new Admin(email,password);
			
			if(l.validateAdmin(a)) {
				System.out.println("Loged in");
				HttpSession session=request.getSession();  
			       
		        session.setAttribute("email",email);
					RequestDispatcher rd=request.getRequestDispatcher("admin.jsp");
					rd.forward(request,response);
			} else {
				
				
				out.println("<html><body>");
				out.println("<p>Invalid credentials</p><br>");
				out.println("<a href='index.jsp'>Home</a><br>");
				out.println("<a href='Registration.jsp'>Back</a><br>");
				out.println("</body></html>");
			}
		}
		}catch(Exception e) {
			
			
			out.println("<html><body>");
			out.println("<p>Invalid Data</p><br>");
			out.println("<a href='index.jsp'>Home</a><br>");
			out.println("<a href='Registration.jsp'>Back</a><br>");
			out.println("</body></html>");
		}
		
		doGet(request, response);
	}

}
